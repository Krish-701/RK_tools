apt update --yes
yes | apt-get install python3.10-tk
apt-get install psmisc --yes

fuser -k 7860/tcp

cd /workspace/kohya_ss

git checkout sd3-flux.1

source venv/bin/activate

pip uninstall xformers --yes

pip install torch==2.5.1+cu124 torchvision --index-url https://download.pytorch.org/whl/cu124

pip install xformers==0.0.28.post3 --index-url https://download.pytorch.org/whl/cu124

./gui.sh --listen=0.0.0.0 --share --noverify