
cd /home/Ubuntu/apps/kohya_ss

git pull

git checkout sd3-flux.1

source venv/bin/activate

./setup.sh

git submodule update --init --recursive

pip uninstall xformers --yes

pip install torch==2.5.1+cu124 torchvision --index-url https://download.pytorch.org/whl/cu124

pip install xformers==0.0.28.post3 --index-url https://download.pytorch.org/whl/cu124

./gui.sh --listen=0.0.0.0 --inbrowser --noverify

# Keep the terminal open
read -p "Press Enter to continue..."