

pip install huggingface_hub

pip install ipywidgets
pip install hf_transfer
export HF_HUB_ENABLE_HF_TRANSFER=1

python3 Download_Train_Models.py --dir /home/Ubuntu/Downloads