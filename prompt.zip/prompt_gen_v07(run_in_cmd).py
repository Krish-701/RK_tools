import os
import re
import csv
import json
import requests
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

################################################################################
# MAKE SURE YOU HAVE:  pip install requests
# Then run:            python my_script.py
# If the Tk window doesn't appear, confirm "python -m tkinter" works on your system.
################################################################################

stop_generation = False
ALL_PROMPTS_MEMORY = {}

# Set your endpoint path if needed (older Ollama versions might use /v1/generate or /api/completions).
OLLAMA_ENDPOINT = "/api/generate"


###############################################################################
# 1) Parsing and Cleaning Output
###############################################################################
def parse_ollama_output(response: str):
    """
    Looks for lines:
      Title: ...
      Description: ...
      Style: ...
    Returns dict or None if not found.
    """
    title_match = re.search(r'(?im)^\s*Title:\s*["“]?(.+?)["”]?\s*$', response)
    desc_match  = re.search(r'(?im)^\s*Description:\s*(.+)$', response)
    style_match = re.search(r'(?im)^\s*Style:\s*(.+)$', response)

    if not title_match and not desc_match and not style_match:
        return None

    title = title_match.group(1).strip() if title_match else ""
    desc  = desc_match.group(1).strip()  if desc_match else ""
    style = style_match.group(1).strip() if style_match else ""

    if not title and not desc and not style:
        return None

    return {"title": title, "description": desc, "style": style}


def clean_parsed_output(parsed_dict: dict):
    """
    Remove single quotes, double quotes, and asterisks from the fields.
    """
    if not parsed_dict:
        return parsed_dict
    for key in ["title", "description", "style"]:
        if key in parsed_dict:
            # Remove any single quotes, double quotes, and asterisks:
            parsed_dict[key] = re.sub(r'[\"\'\*]', '', parsed_dict[key])
    return parsed_dict


###############################################################################
# 2) Building the System Prompt (with optional memory)
###############################################################################
def build_system_prompt_with_memory(model_name: str, basic_prompt: str):
    """
    If memory is enabled and we have stored prompts for the model,
    add them as 'already generated' to avoid duplicates.
    """
    if model_name not in ALL_PROMPTS_MEMORY or not ALL_PROMPTS_MEMORY[model_name]:
        return basic_prompt

    memory_text = "\n".join(
        f"{idx+1}) {p['title']} | {p['description']} | {p['style']}"
        for idx, p in enumerate(ALL_PROMPTS_MEMORY[model_name])
    )
    return f"""SYSTEM:
You are an AI specialized in creating random, photorealistic prompts.
Already generated for {model_name}:
{memory_text}

Do NOT repeat those. Provide something brand-new and unique.

{basic_prompt}
"""


###############################################################################
# 3) Memory Reset/Display
###############################################################################
def reset_memory_func(gui_elements):
    global ALL_PROMPTS_MEMORY
    ALL_PROMPTS_MEMORY.clear()
    msg = "[INFO] All memory has been reset.\n"
    gui_elements["model1_log_box"].insert(tk.END, msg)
    if gui_elements["auto_scroll_var"].get() == 1:
        gui_elements["model1_log_box"].see(tk.END)


def show_memory_func(gui_elements):
    global ALL_PROMPTS_MEMORY
    model1_log_box = gui_elements["model1_log_box"]

    if not ALL_PROMPTS_MEMORY:
        msg = "[INFO] No memory stored for any model.\n"
        model1_log_box.insert(tk.END, msg)
    else:
        msg = "[INFO] Current stored memory:\n"
        model1_log_box.insert(tk.END, msg)
        for model, prompts in ALL_PROMPTS_MEMORY.items():
            line = f" Model: {model}\n"
            model1_log_box.insert(tk.END, line)
            if not prompts:
                subline = "   (no prompts)\n"
                model1_log_box.insert(tk.END, subline)
            else:
                for idx, p in enumerate(prompts, start=1):
                    entry = (
                        f"   {idx}) Title:{p['title']}\n"
                        f"      Description:{p['description']}\n"
                        f"      Style:{p['style']}\n"
                    )
                    model1_log_box.insert(tk.END, entry)
    if gui_elements["auto_scroll_var"].get() == 1:
        model1_log_box.see(tk.END)


###############################################################################
# 4) Saving Prompts to CSV
###############################################################################
def save_prompts_to_csv(prompts_list, output_csv, save_mode, model_name, log_box, auto_scroll):
    if not prompts_list:
        return
    dirpath = os.path.dirname(output_csv)
    if dirpath and not os.path.exists(dirpath):
        os.makedirs(dirpath, exist_ok=True)
    file_mode = "a" if save_mode == "append" else "w"
    write_header = True
    if file_mode == "a" and os.path.exists(output_csv):
        write_header = False
    try:
        with open(output_csv, mode=file_mode, newline="", encoding="utf-8") as csvfile:
            fieldnames = ["Title", "Description", "Style"]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            if write_header:
                writer.writeheader()
            for p in prompts_list:
                writer.writerow({
                    "Title": p["title"],
                    "Description": p["description"],
                    "Style": p["style"]
                })
        log_box.insert(tk.END, f"[{model_name}] Auto-saved {len(prompts_list)} prompts to {output_csv}.\n")
        if auto_scroll:
            log_box.see(tk.END)
    except Exception as e:
        log_box.insert(tk.END, f"[ERROR] CSV write failed for model '{model_name}': {str(e)}\n")
        if auto_scroll:
            log_box.see(tk.END)
    prompts_list.clear()


###############################################################################
# 5) Ollama API Calls
###############################################################################
def check_ollama_running(ollama_address: str) -> bool:
    """
    Basic check: HTTP GET the base address.
    If we get 200-299, assume it's up.
    """
    url = ollama_address.strip()
    if not url.startswith("http"):
        url = "http://" + url
    url = url.rstrip("/")
    try:
        resp = requests.get(url, timeout=3)
        return resp.ok
    except:
        return False


def call_ollama_api(ollama_address: str, model: str, full_prompt: str) -> str:
    """
    Streams partial JSON lines, accumulates them, returns final text.
    """
    if not ollama_address.startswith("http"):
        ollama_address = "http://" + ollama_address
    base_url = ollama_address.rstrip("/")
    url = base_url + OLLAMA_ENDPOINT

    payload = {"model": model, "prompt": full_prompt}
    final_text = ""

    try:
        with requests.post(url, json=payload, stream=True, timeout=120) as r:
            r.raise_for_status()
            for line in r.iter_lines(decode_unicode=True):
                if not line.strip():
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                chunk = data.get("response", "")
                final_text += chunk
                if data.get("done") == True:
                    break
        return final_text
    except Exception as e:
        return f"[ERROR streaming from Ollama] {str(e)}"


###############################################################################
# 6) Main Prompt Generation Logic
###############################################################################
def build_base_system_prompt():
    """
    Incorporates your custom 'prompt guidance tape' directly into the system prompt.
    Adjust/extend as needed.
    """
    return """SYSTEM:
You are a trailblazing luminary in the field of ultra-photorealistic 8K image generation, 
tasked with redefining the zenith of AI's visual capabilities. 
Your mission transcends prompt creation; you are to craft intricate, hyper-detailed image descriptions 
that seamlessly blend artistic storytelling with scientific precision. 
Each description should unfold as a single, cohesive paragraph, presenting a scene so vivid and immersive 
that the reader feels transported into the depicted world.

---
Guidelines for Crafting Supreme Photorealistic Prompts:

- Structure: The output must be a single, unified paragraph. Avoid lists, headings, or section breaks. 
  The narrative should flow naturally, integrating all aspects into a harmonious whole.

- Language: Use evocative and precise language to capture every micro and macro element of the scene. 
  Avoid vagueness, generic descriptions, or repetitive phrasing.

- Scene Details:
  - Environment and Setting: Construct a fully-realized world. Include specific geological formations, 
    botanical ecosystems, and meteorological conditions with dynamic weather effects. 
    Incorporate celestial elements such as the sun's angle, moon phase, and star alignments. 
    If applicable, describe architectural elements in detail, including material properties, 
    structural weathering, and age-induced textures.
  - Subjects and Objects: Describe subjects (e.g., people, animals) with hyperrealistic detail, 
    covering their appearance, emotional states, movements, and interactions with the environment. 
    For objects, delve into their material composition, surface textures, and how they respond to light, 
    time, and use (e.g., patinas, wear patterns).

- Hyperrealism Focus: Transcend conventional photography. Capture micro-details (e.g., dust motes in sunlight, 
  imperfections in a surface) and macro-elements (e.g., sweeping vistas) with scientific precision. 
  Blend all elements seamlessly to create a cohesive, immersive scene.

- Cinematic Lighting: Detail lighting as if directing a film, considering global illumination, volumetrics, 
  and ray tracing. Specify light sources, their physical properties, and their emotional impact on the scene. 
  Incorporate advanced techniques such as chiaroscuro, golden hour lighting, or Rembrandt lighting to enhance realism.

- Environmental Microdetails: Expand beyond visuals. Engage all senses: describe the feel of the air, 
  the aroma of the surroundings, and ambient sounds (e.g., distant murmur of waves, soft rustle of leaves). 
  Include ephemeral elements like heat haze, raindrops sliding down leaves, or shadows shifting as clouds drift by.

- Material Properties and Textures: Portray materials with precision. Capture tactile qualities (e.g., rough stone, 
  polished metal), light interactions (e.g., subsurface scattering, anisotropy), 
  and even molecular-level details like moisture or oxidation effects.

- Temporal Dynamics: Anchor the scene in a specific moment in time, emphasizing seasonal cues, 
  light movement, and shifting weather conditions. Show how time's passage subtly influences 
  the environment (e.g., dew evaporating under sunlight, shadows elongating at dusk).

- Optical Precision: Simulate the nuances of human vision or high-end lenses. 
  Include details like depth of field, bokeh effects, and subtle aberrations that lend authenticity. 
  Avoid artificial artifacts or inconsistencies.

- Compositional Mastery: Guide the viewer’s eye through the scene using advanced principles 
  like leading lines, golden ratios, and framing. Ensure the scene evokes an emotional response 
  and tells a visual story, engaging both the heart and mind.

- Color Grading and Tonality: Use advanced color theory to create a resonant mood. 
  Detail the scene’s color palette (e.g., warm tones for sunrise, cool blues for a misty night) 
  and how tonal mapping enhances emotional depth.

- Negative Prompts: Implicitly eliminate digital artifacts or features that detract from realism. 
  Avoid anything artificial, inconsistent, or out of place (e.g., floating objects, unnatural shadows). 
  Ensure the scene feels grounded in reality.

---
Output Format:
Produce a single-paragraph description that cohesively integrates all the above elements. 
The description must evoke a vivid, photorealistic image, balancing storytelling with scientific detail. 
Do not include explanations, lists, or additional information—focus entirely on the imagery.
"""


def build_user_prompt(custom_title: str, custom_style: str, custom_detail: str, reference_text: str) -> str:
    """
    Constructs the USER prompt portion, guiding the model based on user inputs.
    If a field is empty, we treat it as 'random.'
    """
    lines = ["USER:"]

    # Title
    if custom_title.strip():
        lines.append(f"Use this Title exactly: '{custom_title}'")
    else:
        lines.append("Generate a random Title.")

    # Style
    if custom_style.strip():
        lines.append(f"Use this Style exactly: '{custom_style}'")
    else:
        lines.append("Generate a random Style.")

    # Detail
    if custom_detail.strip():
        lines.append(f"Follow this detail guideline: '{custom_detail}'")
    else:
        lines.append("Use a random detail guideline.")

    # Reference text
    if reference_text.strip():
        lines.append(f"Incorporate this reference: '{reference_text}'")

    lines.append("Now generate exactly 1 new prompt with fields: Title:, Description:, Style:")

    return "\n".join(lines)


def generate_prompts_for_model(
    model_name: str,
    num_prompts: int,
    output_csv: str,
    reference_text: str,
    use_memory: bool,
    save_mode: str,
    log_box: tk.Text,
    progress_bar: ttk.Progressbar,
    auto_scroll: bool,
    auto_save_every: int,
    ollama_address: str,
    custom_title: str,
    custom_style: str,
    custom_detail: str
):
    global stop_generation, ALL_PROMPTS_MEMORY
    if model_name not in ALL_PROMPTS_MEMORY:
        ALL_PROMPTS_MEMORY[model_name] = []
    new_prompts_this_run = []

    base_system = build_base_system_prompt()

    prompt_index = 0
    attempts = 0
    max_attempts = num_prompts * 10  # Attempt more times to avoid duplicates

    while prompt_index < num_prompts and attempts < max_attempts:
        if stop_generation:
            log_box.insert(tk.END, f"\n[INFO] Generation for model '{model_name}' stopped by user.\n")
            if auto_scroll:
                log_box.see(tk.END)
            break

        attempts += 1

        if use_memory:
            system_part = build_system_prompt_with_memory(model_name, base_system)
        else:
            system_part = base_system

        user_part = build_user_prompt(custom_title, custom_style, custom_detail, reference_text)
        final_prompt = f"{system_part}\n\n{user_part}\n"

        # Call Ollama
        response_text = call_ollama_api(ollama_address, model_name, final_prompt)

        parsed = parse_ollama_output(response_text)
        if not parsed:
            # If we can't parse Title/Description/Style, store raw text
            parsed = {
                "title": "UNPARSED",
                "description": response_text,
                "style": ""
            }

        # Clean up undesired characters
        parsed = clean_parsed_output(parsed)

        #######################################################################
        # POST-PROCESSING STEP TO REMOVE "UNPARSED" TITLE & STRIP MARKDOWN
        #######################################################################
        # 1) If the title is "UNPARSED," blank it out so "Title: UNPARSED" never appears:
        if parsed["title"].upper() == "UNPARSED":
            parsed["title"] = ""

        # 2) Remove leading "##", "###", "**" from the description, or any leftover Markdown
        if parsed["description"]:
            lines = parsed["description"].splitlines()
            cleaned_lines = []
            for line in lines:
                # remove ### or ## or ** from the start of each line
                line = re.sub(r"^(#{1,3}\s*|\*{2,})", "", line).strip()
                cleaned_lines.append(line)
            # Re-join into one paragraph (or you can join with '\n' if you prefer multiline)
            parsed["description"] = " ".join(cleaned_lines)
        #######################################################################

        # Check for duplicates
        if use_memory:
            is_duplicate = any(
                p["title"] == parsed["title"]
                and p["description"] == parsed["description"]
                and p["style"] == parsed["style"]
                for p in ALL_PROMPTS_MEMORY[model_name]
            )
        else:
            is_duplicate = any(
                p["title"] == parsed["title"]
                and p["description"] == parsed["description"]
                and p["style"] == parsed["style"]
                for p in new_prompts_this_run
            )

        if is_duplicate:
            log_box.insert(tk.END, f"[{model_name}] Attempt {attempts}: Found duplicate, skipping.\n")
            if auto_scroll:
                log_box.see(tk.END)
            continue

        # If it's new, accept it
        prompt_index += 1
        new_prompts_this_run.append(parsed)
        if use_memory:
            ALL_PROMPTS_MEMORY[model_name].append(parsed)

        # Print to the log box
        log_box.insert(
            tk.END,
            f"[{model_name}] Prompt #{prompt_index}/{num_prompts}\n"
            f"Title: {parsed['title']}\n"
            f"Description: {parsed['description']}\n"
            f"Style: {parsed['style']}\n\n"
        )
        if auto_scroll:
            log_box.see(tk.END)

        progress_value = int((prompt_index / num_prompts) * 100)
        progress_bar["value"] = progress_value

        # Auto-save partial results if needed
        if auto_save_every > 0 and (prompt_index % auto_save_every == 0):
            save_prompts_to_csv(
                prompts_list=new_prompts_this_run,
                output_csv=output_csv,
                save_mode=save_mode,
                model_name=model_name,
                log_box=log_box,
                auto_scroll=auto_scroll
            )

    # After finishing or stopping
    if new_prompts_this_run:
        save_prompts_to_csv(
            prompts_list=new_prompts_this_run,
            output_csv=output_csv,
            save_mode=save_mode,
            model_name=model_name,
            log_box=log_box,
            auto_scroll=auto_scroll
        )
    else:
        log_box.insert(tk.END, f"[{model_name}] No new prompts left to save.\n")
        if auto_scroll:
            log_box.see(tk.END)


###############################################################################
# 7) Thread Logic to Run the Generation
###############################################################################
def generate_prompts_threaded(gui_elements):
    global stop_generation
    stop_generation = False

    use_memory = (gui_elements["use_memory_var"].get() == 1)
    save_mode = gui_elements["save_mode_var"].get()
    auto_scroll = (gui_elements["auto_scroll_var"].get() == 1)
    auto_save_every_str = gui_elements["auto_save_every_var"].get()

    try:
        auto_save_every = int(auto_save_every_str)
        if auto_save_every < 0:
            auto_save_every = 0
    except ValueError:
        auto_save_every = 50

    ollama_address = gui_elements["ollama_address_var"].get().strip()
    if not ollama_address:
        messagebox.showerror("No Ollama Address", "Please enter your Ollama server IP:port or URL.")
        return

    if not check_ollama_running(ollama_address):
        messagebox.showerror(
            "Ollama Not Running",
            f"Could not connect to Ollama at '{ollama_address}'.\n"
            "Ensure it's started in server mode and IP:port is correct."
        )
        gui_elements["model1_log_box"].insert(tk.END, "[ERROR] Ollama is unreachable.\n")
        return

    model1_name = gui_elements["model1_var"].get().strip()
    model1_count = int(gui_elements["prompt_count1_var"].get())
    model1_csv = gui_elements["output_file1_var"].get().strip()
    model1_log_box = gui_elements["model1_log_box"]
    progress_bar1 = gui_elements["progress_bar1"]
    reference1_text = gui_elements["reference1_text"].get("1.0", tk.END).strip()

    # NEW: Pull Title/Style/Detail from the GUI
    custom_title = gui_elements["title_var"].get().strip()
    custom_style = gui_elements["style_var"].get().strip()
    custom_detail = gui_elements["detail_var"].get().strip()

    def worker1():
        generate_prompts_for_model(
            model_name=model1_name,
            num_prompts=model1_count,
            output_csv=model1_csv,
            reference_text=reference1_text,
            use_memory=use_memory,
            save_mode=save_mode,
            log_box=model1_log_box,
            progress_bar=progress_bar1,
            auto_scroll=auto_scroll,
            auto_save_every=auto_save_every,
            ollama_address=ollama_address,
            custom_title=custom_title,
            custom_style=custom_style,
            custom_detail=custom_detail,
        )

    t1 = threading.Thread(target=worker1)
    t1.start()
    t1.join()

    model1_log_box.insert(tk.END, "[INFO] Generation process finished.\n")
    if auto_scroll:
        model1_log_box.see(tk.END)


def start_generation(gui_elements):
    thread = threading.Thread(target=generate_prompts_threaded, args=(gui_elements,))
    thread.start()


def stop_generation_func():
    global stop_generation
    stop_generation = True


def browse_csv_file(output_file_var):
    filepath = filedialog.asksaveasfilename(
        defaultextension=".csv",
        filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
    )
    if filepath:
        output_file_var.set(filepath)


###############################################################################
# 8) Main TKinter GUI (Single Model Only)
###############################################################################
def main():
    root = tk.Tk()
    root.title("Ollama Prompt Generator (Single Model)")
    root.geometry("900x800")
    root.resizable(True, True)

    main_canvas = tk.Canvas(root)
    main_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    v_scrollbar = ttk.Scrollbar(root, orient=tk.VERTICAL, command=main_canvas.yview)
    v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    main_canvas.configure(yscrollcommand=v_scrollbar.set)

    container = ttk.Frame(main_canvas)
    main_canvas.create_window((0,0), window=container, anchor="nw")

    def update_scrollregion(event=None):
        main_canvas.config(scrollregion=main_canvas.bbox("all"))

    container.bind("<Configure>", update_scrollregion)

    # ============ Ollama Address ============
    ollama_address_frame = ttk.LabelFrame(container, text="Ollama Server Address")
    ollama_address_frame.pack(fill=tk.X, padx=10, pady=5)

    ttk.Label(
        ollama_address_frame,
        text="Example: 192.200.0.229:11434 or http://192.200.0.222:11434"
    ).pack(side=tk.LEFT, padx=5, pady=5)

    ollama_address_var = tk.StringVar(value="")
    ollama_address_entry = ttk.Entry(ollama_address_frame, textvariable=ollama_address_var, width=40)
    ollama_address_entry.pack(side=tk.LEFT, padx=5, pady=5)

    # ============ Model Configuration ============
    model1_frame = ttk.LabelFrame(container, text="Model Configuration")
    model1_frame.pack(fill=tk.X, padx=10, pady=5)

    ttk.Label(model1_frame, text="Model Name:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
    model1_var = tk.StringVar(value="mistral-small:22b-instruct-2409-q8_0")
    model1_entry = ttk.Entry(model1_frame, textvariable=model1_var, width=30)
    model1_entry.grid(row=0, column=1, padx=5, pady=2, sticky=tk.W)

    ttk.Label(model1_frame, text="Number of Prompts:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
    prompt_count1_var = tk.StringVar(value="5")
    prompt_count1_entry = ttk.Entry(model1_frame, textvariable=prompt_count1_var, width=10)
    prompt_count1_entry.grid(row=1, column=1, padx=5, pady=2, sticky=tk.W)

    ttk.Label(model1_frame, text="Output CSV:").grid(row=2, column=0, sticky=tk.W, padx=5, pady=2)
    output_file1_var = tk.StringVar(value="C:/prompts/unique_prompts.csv")
    output_file1_entry = ttk.Entry(model1_frame, textvariable=output_file1_var, width=40)
    output_file1_entry.grid(row=2, column=1, padx=5, pady=2, sticky=tk.W)

    browse1_btn = ttk.Button(
        model1_frame, text="Browse...",
        command=lambda: browse_csv_file(output_file1_var)
    )
    browse1_btn.grid(row=2, column=2, padx=5, pady=2, sticky=tk.W)

    ref1_frame = ttk.LabelFrame(model1_frame, text="Reference Prompt")
    ref1_frame.grid(row=3, column=0, columnspan=3, sticky=tk.W+tk.E, padx=5, pady=5)

    reference1_text = tk.Text(ref1_frame, height=10, wrap=tk.WORD)
    reference1_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    # -------------------------------------------------------------------------
    # SHOW YOUR “LLM INSTRUCTION” INSIDE REFERENCE PROMPT BY DEFAULT
    # -------------------------------------------------------------------------
    default_instruction = (
        "Below is your LLM instruction or 'prompt guidance tape'. You can edit or add text as desired.\n\n"
        "Guidelines for Crafting Supreme Photorealistic Prompts:\n"
        "- Structure: The output must be a single, unified paragraph.\n"
        "- Language: Use evocative and precise language.\n"
        "- Scene Details: Include environment, setting, subjects, etc.\n"
        "- Hyperrealism Focus: Micro-details + macro-elements.\n"
        "- Cinematic Lighting: Consider film-like lighting strategies.\n"
        "- Environmental Microdetails: Engage all senses.\n"
        "- Material Properties and Textures: Portray materials with precision.\n"
        "- Temporal Dynamics: Emphasize changing conditions over time.\n"
        "- Optical Precision: Subtle lens effects.\n"
        "- Compositional Mastery: Use advanced composition rules.\n"
        "- Color Grading and Tonality: Use advanced color theory.\n"
        "- Negative Prompts: Remove digital artifacts.\n\n"
        "Edit this section if you want a different reference prompt or instructions..."
    )
    reference1_text.insert(tk.END, default_instruction)
    # -------------------------------------------------------------------------

    # ============ Additional Fields for Title / Style / Detail ============
    custom_input_frame = ttk.LabelFrame(container, text="Custom Prompt Options (Optional)")
    custom_input_frame.pack(fill=tk.X, padx=10, pady=5)

    # Title
    ttk.Label(custom_input_frame, text="Title:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
    title_var = tk.StringVar(value="")
    title_entry = ttk.Entry(custom_input_frame, textvariable=title_var, width=30)
    title_entry.grid(row=0, column=1, padx=5, pady=2, sticky=tk.W)

    # Style
    ttk.Label(custom_input_frame, text="Style:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
    style_var = tk.StringVar(value="")
    style_entry = ttk.Entry(custom_input_frame, textvariable=style_var, width=30)
    style_entry.grid(row=1, column=1, padx=5, pady=2, sticky=tk.W)

    # Detail
    ttk.Label(custom_input_frame, text="Detail:").grid(row=2, column=0, sticky=tk.W, padx=5, pady=2)
    detail_var = tk.StringVar(value="")
    detail_entry = ttk.Entry(custom_input_frame, textvariable=detail_var, width=30)
    detail_entry.grid(row=2, column=1, padx=5, pady=2, sticky=tk.W)

    # ============ Settings ============
    settings_frame = ttk.LabelFrame(container, text="Settings")
    settings_frame.pack(fill=tk.X, padx=10, pady=5)

    use_memory_var = tk.IntVar(value=1)
    memory_check = ttk.Checkbutton(
        settings_frame, text="Use Memory (avoid repeats)",
        variable=use_memory_var
    )
    memory_check.grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)

    ttk.Label(settings_frame, text="Save Mode:").grid(row=0, column=1, sticky=tk.W, padx=5, pady=2)
    save_mode_var = tk.StringVar(value="append")
    overwrite_radio = ttk.Radiobutton(settings_frame, text="Overwrite", variable=save_mode_var, value="overwrite")
    append_radio    = ttk.Radiobutton(settings_frame, text="Append",   variable=save_mode_var, value="append")
    overwrite_radio.grid(row=0, column=2, sticky=tk.W, padx=5, pady=2)
    append_radio.grid(row=0, column=3, sticky=tk.W, padx=5, pady=2)

    ttk.Label(settings_frame, text="Auto Save Every:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
    auto_save_every_var = tk.StringVar(value="50")
    auto_save_every_entry = ttk.Entry(settings_frame, textvariable=auto_save_every_var, width=8)
    auto_save_every_entry.grid(row=1, column=1, padx=5, pady=2, sticky=tk.W)
    ttk.Label(settings_frame, text="prompts").grid(row=1, column=2, sticky=tk.W, padx=5, pady=2)

    auto_scroll_var = tk.IntVar(value=1)
    auto_scroll_check = ttk.Checkbutton(
        settings_frame, text="Auto-scroll to bottom",
        variable=auto_scroll_var
    )
    auto_scroll_check.grid(row=1, column=3, padx=5, pady=2, sticky=tk.W)

    # ============ Action Buttons ============
    action_frame = ttk.Frame(container)
    action_frame.pack(fill=tk.X, padx=10, pady=5)

    model1_log_box = None
    progress_bar1 = None

    start_button = ttk.Button(
        action_frame, text="Start Generation",
        command=lambda: start_generation({
            "model1_var": model1_var,
            "prompt_count1_var": prompt_count1_var,
            "output_file1_var": output_file1_var,
            "reference1_text": reference1_text,
            "use_memory_var": use_memory_var,
            "save_mode_var": save_mode_var,
            "model1_log_box": model1_log_box,
            "progress_bar1": progress_bar1,
            "auto_scroll_var": auto_scroll_var,
            "auto_save_every_var": auto_save_every_var,
            "ollama_address_var": ollama_address_var,
            "title_var": title_var,
            "style_var": style_var,
            "detail_var": detail_var,
        })
    )
    start_button.pack(side=tk.LEFT, padx=5)

    stop_button = ttk.Button(action_frame, text="Stop", command=stop_generation_func)
    stop_button.pack(side=tk.LEFT, padx=5)

    # Reset Memory
    reset_button = ttk.Button(
        action_frame, text="Reset Memory",
        command=lambda: reset_memory_func({
            "model1_log_box": model1_log_box,
            "auto_scroll_var": auto_scroll_var
        })
    )
    reset_button.pack(side=tk.LEFT, padx=5)

    # Show Memory
    showmem_button = ttk.Button(
        action_frame, text="Show Memory",
        command=lambda: show_memory_func({
            "model1_log_box": model1_log_box,
            "auto_scroll_var": auto_scroll_var
        })
    )
    showmem_button.pack(side=tk.LEFT, padx=5)

    # ============ Clear Logs ============
    clear_logs_frame = ttk.Frame(container)
    clear_logs_frame.pack(fill=tk.X, padx=10, pady=5)

    ttk.Label(clear_logs_frame, text="Clear Log:").pack(side=tk.LEFT, padx=5)

    # ============ Model #1 Log ============
    model1_log_frame = ttk.LabelFrame(container, text="Generation Log")
    model1_log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

    model1_scrollbar = ttk.Scrollbar(model1_log_frame, orient=tk.VERTICAL)
    model1_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    model1_log_box = tk.Text(model1_log_frame, wrap=tk.WORD, yscrollcommand=model1_scrollbar.set)
    model1_log_box.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    model1_scrollbar.config(command=model1_log_box.yview)

    clear_button = ttk.Button(
        clear_logs_frame, text="Clear Log",
        command=lambda: model1_log_box.delete("1.0", tk.END)
    )
    clear_button.pack(side=tk.LEFT, padx=5)

    # ============ Progress Bar ============
    progress_frame = ttk.Frame(container)
    progress_frame.pack(fill=tk.X, padx=10, pady=5)

    progress_bar1 = ttk.Progressbar(progress_frame, orient="horizontal", length=450, mode="determinate")
    progress_bar1.pack(side=tk.LEFT, padx=5)

    # Update the command of the start_button now that we have references
    start_button.configure(
        command=lambda: start_generation({
            "model1_var": model1_var,
            "prompt_count1_var": prompt_count1_var,
            "output_file1_var": output_file1_var,
            "reference1_text": reference1_text,
            "use_memory_var": use_memory_var,
            "save_mode_var": save_mode_var,
            "model1_log_box": model1_log_box,
            "progress_bar1": progress_bar1,
            "auto_scroll_var": auto_scroll_var,
            "auto_save_every_var": auto_save_every_var,
            "ollama_address_var": ollama_address_var,
            "title_var": title_var,
            "style_var": style_var,
            "detail_var": detail_var,
        })
    )

    root.mainloop()


# --------------------------------------
# LAUNCH
# --------------------------------------
if __name__ == "__main__":
    main()
