
apt-get update --yes
apt-get install python3-tk --yes
apt update --yes
apt install ninja-build --yes
pip install requests
pip install tqdm
git lfs install
apt install zram-config
mkdir -p /workspace/virtualRAM
cd /workspace/virtualRAM
# Check available space
df -h /dev/shm

# Create a symbolic link for easier access
ln -s /dev/shm /workspace/virtualRAM

cd /workspace
git clone https://github.com/FurkanGozukara/Sana
cd Sana

python -m venv venv

source ./venv/bin/activate

cd ..

pip install -U xformers==0.0.27.post2 torchvision --index-url https://download.pytorch.org/whl/cu121

pip install -r requirements.txt

cd Sana

pip install -e .

pip install triton

cd ..

export HF_HUB_ENABLE_HF_TRANSFER=1

python Download_Models.py

# Show completion message
echo "Installation successfully completed - check install logs for any error or not"

