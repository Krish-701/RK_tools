pip install requests
pip install tqdm
sudo apt update
git lfs install
sudo apt update --yes
sudo apt install ninja-build --yes
sudo apt install zram-config --yes
df -h /dev/shm


git clone https://github.com/FurkanGozukara/Sana
cd Sana

python3 -m venv venv

source ./venv/bin/activate

cd ..

pip install -U xformers==0.0.27.post2 torchvision --index-url https://download.pytorch.org/whl/cu121

pip install -r requirements.txt

cd Sana

pip install -e .

pip install triton

cd ..

export HF_HUB_ENABLE_HF_TRANSFER=1

python3 Download_Models.py

# Keep the terminal open
read -p "Installation successfully completed - check install logs for any error or not"
