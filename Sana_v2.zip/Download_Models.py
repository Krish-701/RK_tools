# You can run this cell multiple times if any error occurs it will resume

from huggingface_hub import snapshot_download
import os

# Ensure the local directory exists


snapshot_download(
            repo_id="Efficient-Large-Model/Sana_1600M_1024px",
            allow_patterns="*/Sana_1600M_1024px.pth",
            local_dir=f"Sana/models"
        )

print(".\n.\nDOWNLOAD COMPLETED into Sana/models")