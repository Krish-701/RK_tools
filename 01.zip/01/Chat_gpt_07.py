import os
import re
import sys
import json
import subprocess
import requests
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

##############################################################################
# GLOBALS
##############################################################################

stop_chat = False
CHAT_HISTORY = []
save_counter = 1  # increments each time we auto-save

##############################################################################
# 1) REAL API CALLS
##############################################################################

def call_ollama_api(address: str, model: str, conversation_list: list) -> str:
    if not address.startswith("http"):
        address = "http://" + address
    url = address.rstrip("/") + "/api/generate"

    full_text = ""
    for item in conversation_list:
        role = item["role"]
        text = item["content"]
        if role == "system":
            full_text += f"SYSTEM:\n{text}\n\n"
        elif role == "user":
            full_text += f"USER:\n{text}\n\n"
        else:
            full_text += f"{role.upper()}:\n{text}\n\n"
    full_text += "ASSISTANT:\n"

    payload = {
        "model": model,
        "prompt": full_text,
        "stream": True
    }

    final_text = ""
    try:
        with requests.post(url, json=payload, stream=True, timeout=120) as r:
            r.raise_for_status()
            for line in r.iter_lines(decode_unicode=True):
                if not line.strip():
                    continue
                try:
                    data = json.loads(line)
                    final_text += data.get("response", "")
                    if data.get("done"):
                        break
                except json.JSONDecodeError:
                    continue
        return final_text.strip()
    except Exception as e:
        return f"[ERROR streaming from Ollama] {str(e)}"

def call_groq_api(api_key: str, model: str, conversation_list: list) -> str:
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    messages = []
    for item in conversation_list:
        messages.append({"role": item["role"], "content": item["content"]})

    data = {"model": model, "messages": messages}
    try:
        resp = requests.post(url, headers=headers, json=data, timeout=120)
        resp.raise_for_status()
        j = resp.json()
        if "choices" in j and j["choices"]:
            return j["choices"][0]["message"]["content"]
        return "[ERROR] Groq response missing 'choices'"
    except Exception as e:
        return f"[ERROR from Groq] {str(e)}"

def call_openai_api(api_key: str, model: str, conversation_list: list) -> str:
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    messages = []
    for item in conversation_list:
        messages.append({"role": item["role"], "content": item["content"]})

    data = {"model": model, "messages": messages}
    try:
        resp = requests.post(url, headers=headers, json=data, timeout=120)
        resp.raise_for_status()
        j = resp.json()
        if "choices" in j and j["choices"]:
            return j["choices"][0]["message"]["content"]
        return "[ERROR] OpenAI response missing 'choices'"
    except Exception as e:
        return f"[ERROR from OpenAI] {str(e)}"

def call_together_api(api_key: str, model: str, conversation_list: list) -> str:
    url = "https://api.together.xyz/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    messages = []
    for item in conversation_list:
        messages.append({"role": item["role"], "content": item["content"]})

    data = {"model": model, "messages": messages, "stream": False}
    try:
        resp = requests.post(url, headers=headers, json=data, timeout=120)
        resp.raise_for_status()
        j = resp.json()
        if "choices" in j and j["choices"]:
            return j["choices"][0]["message"]["content"]
        return "[ERROR] Together response missing 'choices'"
    except Exception as e:
        return f"[ERROR from Together] {str(e)}"

def call_google_genai_api(api_key: str, model: str, conversation_list: list) -> str:
    """
    Old script style mapping for Google models.
    """
    try:
        import google.generativeai as genai
    except ImportError:
        return "[ERROR from Google] 'google-generativeai' not installed."

    google_map = {
        "gemini-2.0-flash-exp":       "gemini-2.0-flash-exp",
        "gemini-1.5-flash-latest":    "gemini-1.5-flash-latest",
        "gemini-1.5-flash-8b-latest": "gemini-1.5-flash-8b-latest",
        "gemini-1.5-pro-latest":      "gemini-1.5-pro-latest"
    }
    if model in google_map:
        model = google_map[model]

    system_text = ""
    user_text   = ""
    for item in conversation_list:
        if item["role"] == "system":
            system_text += item["content"] + "\n\n"
        elif item["role"] == "user":
            user_text += f"USER: {item['content']}\n"
        elif item["role"] == "assistant":
            user_text += f"ASSISTANT: {item['content']}\n"
        else:
            user_text += f"{item['role'].upper()}: {item['content']}\n"

    full_prompt = f"{system_text}\n\n{user_text}\nASSISTANT:\n"

    try:
        genai.configure(api_key=api_key)
        gm = genai.GenerativeModel(model)
        res = gm.generate_content(full_prompt)
        return res.text or "[EMPTY from Google]"
    except Exception as e:
        return f"[ERROR from Google] {str(e)}"

def call_deepseek_api(api_key: str, model: str, conversation_list: list) -> str:
    """
    Calls DeepSeek via the openai-like API.
    """
    try:
        from openai import OpenAI
    except ImportError:
        return "[ERROR from DeepSeek] 'openai' package not installed. Please pip install openai."

    messages = []
    for item in conversation_list:
        messages.append({"role": item["role"], "content": item["content"]})

    try:
        client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com")
        resp = client.chat.completions.create(model=model, messages=messages, stream=False)
        if hasattr(resp, "choices") and resp.choices:
            return resp.choices[0].message.content
        return "[ERROR from DeepSeek] Response missing 'choices'"
    except Exception as e:
        return f"[ERROR from DeepSeek] {str(e)}"

##############################################################################
# 2) DISPATCH
##############################################################################

def call_chat_api(provider: str, gui: dict, conversation_list: list) -> str:
    provider = provider.lower()
    if provider == "ollama":
        address = gui["ollama_address_var"].get().strip()
        model   = gui["ollama_model_var"].get()
        return call_ollama_api(address, model, conversation_list)

    elif provider == "groq":
        api_key = gui["groq_api_key_var"].get().strip()
        model   = gui["groq_model_var"].get()
        return call_groq_api(api_key, model, conversation_list)

    elif provider == "openai":
        api_key = gui["openai_api_key_var"].get().strip()
        model   = gui["openai_model_var"].get()
        return call_openai_api(api_key, model, conversation_list)

    elif provider == "together":
        api_key = gui["together_api_key_var"].get().strip()
        model   = gui["together_model_var"].get()
        return call_together_api(api_key, model, conversation_list)

    elif provider == "google":
        api_key = gui["google_api_key_var"].get().strip()
        model   = gui["google_model_var"].get()
        return call_google_genai_api(api_key, model, conversation_list)

    elif provider == "deepseek":
        api_key = gui["deepseek_api_key_var"].get().strip()
        model   = gui["deepseek_model_var"].get()
        return call_deepseek_api(api_key, model, conversation_list)

    else:
        return "[ERROR] Unknown provider."

##############################################################################
# 3) Export / Import Chat
##############################################################################

def export_chat_txt(chat_history, parent_window, path=None):
    if not chat_history:
        messagebox.showinfo("Empty Chat", "No chat to export.")
        return

    if path is None:
        path = filedialog.asksaveasfilename(
            parent=parent_window,
            defaultextension=".txt",
            filetypes=[("Text Files","*.txt"), ("All files","*.*")]
        )
        if not path:
            return

    try:
        with open(path, "w", encoding="utf-8") as f:
            for msg in chat_history:
                f.write(f"role: {msg['role']}\n")
                f.write(f"content: {msg['content']}\n")
                f.write("---\n")
        if parent_window is not None:
            messagebox.showinfo("Exported", f"Chat exported to {path}")
    except Exception as e:
        if parent_window is not None:
            messagebox.showerror("Export Error", str(e))

def import_chat_txt(parent_window, path=None):
    if path is None:
        path = filedialog.askopenfilename(
            parent=parent_window,
            filetypes=[("Text Files","*.txt"), ("All files","*.*")]
        )
        if not path:
            return []

    new_history = []
    current_role = None
    current_content = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line=line.strip("\n")
                if line.startswith("role: "):
                    if current_role is not None:
                        new_history.append({
                            "role": current_role,
                            "content": "\n".join(current_content).strip()
                        })
                    current_role = line[len("role: "):].strip()
                    current_content = []
                elif line.startswith("content: "):
                    cont_line = line[len("content: "):]
                    current_content.append(cont_line)
                elif line.strip() == "---":
                    if current_role is not None:
                        new_history.append({
                            "role": current_role,
                            "content": "\n".join(current_content).strip()
                        })
                    current_role = None
                    current_content = []
                else:
                    current_content.append(line)

        if current_role is not None:
            new_history.append({
                "role": current_role,
                "content": "\n".join(current_content).strip()
            })
        return new_history
    except Exception as e:
        if parent_window is not None:
            messagebox.showerror("Import Error", str(e))
        return []

##############################################################################
# 4) STOP / CLEAR / SEND / LOAD / SAVE
##############################################################################

def stop_chat_func():
    global stop_chat
    stop_chat = True

def clear_chat_func(chat_box: tk.Text):
    global CHAT_HISTORY
    CHAT_HISTORY.clear()
    chat_box.delete("1.0", tk.END)
    chat_box.insert(tk.END, "[INFO] Chat cleared.\n")

def load_chat_func(gui, chat_box):
    global CHAT_HISTORY
    new_hist = import_chat_txt(gui["root"])
    if not new_hist:
        return
    CHAT_HISTORY = new_hist
    chat_box.delete("1.0", tk.END)
    for msg in CHAT_HISTORY:
        chat_box.insert(tk.END, f"{msg['role'].upper()}: {msg['content']}\n\n")
    chat_box.see(tk.END)

def save_chat_func(gui, chat_box):
    global CHAT_HISTORY
    export_chat_txt(CHAT_HISTORY, gui["root"], None)

def auto_save_incremental(gui, chat_box):
    global CHAT_HISTORY, save_counter
    saving_dir = gui["saving_dir_var"].get().strip()
    if not saving_dir:
        return  # no directory set

    if not os.path.exists(saving_dir):
        try:
            os.makedirs(saving_dir)
        except Exception:
            return

    file_name = os.path.join(saving_dir, f"chat_{save_counter:03d}.txt")
    save_counter += 1

    export_chat_txt(CHAT_HISTORY, None, path=file_name)

def send_message(gui_elements: dict):
    global stop_chat, CHAT_HISTORY
    stop_chat = False

    provider = gui_elements["api_provider_var"].get().lower()
    chat_box = gui_elements["chat_box"]
    user_input_box = gui_elements["user_input_box"]
    user_text = user_input_box.get("1.0", tk.END).rstrip("\n")

    if not user_text.strip():
        return

    # Add user message
    CHAT_HISTORY.append({"role":"user", "content":user_text})
    chat_box.insert(tk.END, f"USER: {user_text}\n")

    # Call
    reply_text = call_chat_api(provider, gui_elements, CHAT_HISTORY)
    CHAT_HISTORY.append({"role":"assistant", "content":reply_text})

    chat_box.insert(tk.END, f"ASSISTANT: {reply_text}\n\n")
    chat_box.see(tk.END)

    if gui_elements["auto_save_var"].get() == 1:
        auto_save_incremental(gui_elements, chat_box)

##############################################################################
# 5) API KEY LOADER
##############################################################################

def load_api_keys(gui):
    """
    Reads a text file with lines like:
      groq=abc123
      openai=xxxYYY
      google=someKey
      deepseek=98765
      ollama=http://localhost:11434
    Then sets those values into the GUI variables.
    """
    path = filedialog.askopenfilename(title="Select your API Key file",
                                      filetypes=[("Text Files", "*.txt"), ("All files", "*.*")])
    if not path:
        return
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        for line in lines:
            line=line.strip()
            if not line or "=" not in line:
                continue
            key, val = line.split("=", 1)
            key = key.strip().lower()
            val = val.strip()
            if key == "groq":
                gui["groq_api_key_var"].set(val)
            elif key == "openai":
                gui["openai_api_key_var"].set(val)
            elif key == "together":
                gui["together_api_key_var"].set(val)
            elif key == "google":
                gui["google_api_key_var"].set(val)
            elif key == "deepseek":
                gui["deepseek_api_key_var"].set(val)
            elif key == "ollama":
                gui["ollama_address_var"].set(val)

        messagebox.showinfo("Keys Loaded", "API keys and/or Ollama address loaded from file.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

##############################################################################
# 6) COPY LAST ASSISTANT REPLY
##############################################################################

def copy_last_assistant(gui):
    """
    Find the most recent Assistant message in CHAT_HISTORY, copy to clipboard.
    """
    root = gui["root"]
    global CHAT_HISTORY
    for msg in reversed(CHAT_HISTORY):
        if msg["role"] == "assistant":
            text_to_copy = msg["content"]
            root.clipboard_clear()
            root.clipboard_append(text_to_copy)
            root.update()  # to ensure the clipboard is actually updated
            messagebox.showinfo("Copied", "Assistant reply copied to clipboard.")
            return
    messagebox.showinfo("No assistant reply", "No assistant message found to copy.")

##############################################################################
# 7) REFRESH MODEL
##############################################################################

def refresh_model_func(gui):
    """
    Just reconfirms which provider + model are selected, logs that info in the chat box.
    (So user can see it is 'definitely' using that model.)
    """
    chat_box = gui["chat_box"]
    provider = gui["api_provider_var"].get()
    if provider == "ollama":
        model = gui["ollama_model_var"].get()
    elif provider == "groq":
        model = gui["groq_model_var"].get()
    elif provider == "openai":
        model = gui["openai_model_var"].get()
    elif provider == "together":
        model = gui["together_model_var"].get()
    elif provider == "google":
        model = gui["google_model_var"].get()
    elif provider == "deepseek":
        model = gui["deepseek_model_var"].get()
    else:
        model = "(unknown)"

    chat_box.insert(tk.END, f"[REFRESH MODEL] Provider: {provider}, Model: {model}\n")
    chat_box.see(tk.END)
    messagebox.showinfo("Model Refreshed", f"Now confirmed to use {provider} -> {model}")

##############################################################################
# MAIN UI
##############################################################################

def main():
    root = tk.Tk()
    root.title("Chat with SHIFT+ENTER multiline, Load Keys Below Models, Refresh Model")

    root.geometry("1200x800")

    # SCROLLABLE MAIN
    main_canvas = tk.Canvas(root)
    main_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    scrollbar_y = ttk.Scrollbar(root, orient=tk.VERTICAL, command=main_canvas.yview)
    scrollbar_y.pack(side=tk.RIGHT, fill=tk.Y)
    main_canvas.configure(yscrollcommand=scrollbar_y.set)

    container = ttk.Frame(main_canvas)
    main_canvas.create_window((0,0), window=container, anchor="nw")

    def on_configure(event):
        main_canvas.configure(scrollregion=main_canvas.bbox("all"))
    container.bind("<Configure>", on_configure)

    def _on_mousewheel(event):
        main_canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    main_canvas.bind("<MouseWheel>", _on_mousewheel)  # Windows/Mac
    main_canvas.bind("<Button-4>", lambda e: main_canvas.yview_scroll(-1, "units"))  # Linux up
    main_canvas.bind("<Button-5>", lambda e: main_canvas.yview_scroll(1, "units"))   # Linux down

    # PROVIDER
    provider_frame = ttk.LabelFrame(container, text="Select Provider (One)")
    provider_frame.pack(fill=tk.X, pady=5)

    api_provider_var = tk.StringVar(value="ollama")
    for p in ["ollama","groq","openai","together","google","deepseek"]:
        ttk.Radiobutton(provider_frame, text=p.capitalize(), variable=api_provider_var, value=p)\
            .pack(side=tk.LEFT, padx=5)

    # MODELS (Horizontal)
    model_frame = ttk.LabelFrame(container, text="Models (Horizontal)")
    model_frame.pack(fill=tk.X, pady=5)

    ollama_address_var    = tk.StringVar(value="http://localhost:11434")
    groq_api_key_var      = tk.StringVar(value="")
    openai_api_key_var    = tk.StringVar(value="")
    together_api_key_var  = tk.StringVar(value="")
    google_api_key_var    = tk.StringVar(value="")
    deepseek_api_key_var  = tk.StringVar(value="")

    ollama_model_var   = tk.StringVar(value="mistral-small:22b-instruct-2409-q8_0")
    groq_model_var     = tk.StringVar(value="llama-3.3-70b-versatile")
    openai_model_var   = tk.StringVar(value="gpt-4")
    together_model_var = tk.StringVar(value="meta-llama/Llama-Vision-Free")
    google_model_var   = tk.StringVar(value="gemini-1.5-flash-latest")
    deepseek_model_var = tk.StringVar(value="deepseek-coder")

    ttk.Label(model_frame, text="Ollama:").pack(side=tk.LEFT, padx=5)
    ollama_combo = ttk.Combobox(model_frame, textvariable=ollama_model_var, width=15)
    ollama_combo["values"] = ("mistral-small:22b-instruct-2409-q8_0","llama3.2:1b")
    ollama_combo.pack(side=tk.LEFT, padx=5)

    ttk.Label(model_frame, text="Groq:").pack(side=tk.LEFT, padx=5)
    groq_combo = ttk.Combobox(model_frame, textvariable=groq_model_var, width=15)
    groq_combo["values"] = ("llama-3.3-70b-versatile","mixtral-8x7b-32768")
    groq_combo.pack(side=tk.LEFT, padx=5)

    ttk.Label(model_frame, text="OpenAI:").pack(side=tk.LEFT, padx=5)
    openai_combo = ttk.Combobox(model_frame, textvariable=openai_model_var, width=15)
    openai_combo["values"] = ("gpt-4","gpt-3.5-turbo")
    openai_combo.pack(side=tk.LEFT, padx=5)

    ttk.Label(model_frame, text="Together:").pack(side=tk.LEFT, padx=5)
    together_combo = ttk.Combobox(model_frame, textvariable=together_model_var, width=15)
    together_combo["values"] = ("meta-llama/Llama-Vision-Free","black-forest-labs/FLUX.1-schnell-Free")
    together_combo.pack(side=tk.LEFT, padx=5)

    ttk.Label(model_frame, text="Google:").pack(side=tk.LEFT, padx=5)
    google_combo = ttk.Combobox(model_frame, textvariable=google_model_var, width=15)
    google_combo["values"] = (
        "gemini-2.0-flash-exp",
        "gemini-1.5-flash-latest",
        "gemini-1.5-flash-8b-latest",
        "gemini-1.5-pro-latest"
    )
    google_combo.pack(side=tk.LEFT, padx=5)

    ttk.Label(model_frame, text="DeepSeek:").pack(side=tk.LEFT, padx=5)
    deepseek_combo = ttk.Combobox(model_frame, textvariable=deepseek_model_var, width=15)
    deepseek_combo["values"] = ("deepseek-coder","deepseek-chat")
    deepseek_combo.pack(side=tk.LEFT, padx=5)

    # KEYS loader button below model area
    keyloader_frame = ttk.Frame(container)
    keyloader_frame.pack(fill=tk.X, pady=5)

    load_keys_btn = ttk.Button(keyloader_frame, text="Load Keys from File")
    load_keys_btn.pack(side=tk.LEFT, padx=10)

    # Chat Output
    chat_frame = ttk.LabelFrame(container, text="Chat History")
    chat_frame.pack(fill=tk.BOTH, expand=True, pady=5)

    scrollbar_chat_vert = ttk.Scrollbar(chat_frame, orient=tk.VERTICAL)
    scrollbar_chat_horz = ttk.Scrollbar(chat_frame, orient=tk.HORIZONTAL)

    chat_box = tk.Text(chat_frame, wrap=tk.NONE,
                       yscrollcommand=scrollbar_chat_vert.set,
                       xscrollcommand=scrollbar_chat_horz.set)
    chat_box.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    scrollbar_chat_vert.config(command=chat_box.yview)
    scrollbar_chat_vert.pack(side=tk.RIGHT, fill=tk.Y)

    scrollbar_chat_horz.config(command=chat_box.xview)
    scrollbar_chat_horz.pack(side=tk.BOTTOM, fill=tk.X)

    # Chat Input
    input_frame = ttk.LabelFrame(container, text="Your Query (SHIFT+ENTER for newline, ENTER to send)")
    input_frame.pack(fill=tk.BOTH, expand=True, pady=5)
    user_input_box = tk.Text(input_frame, height=4, wrap=tk.WORD)
    user_input_box.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def on_input_key(event):
        # SHIFT+ENTER => Insert newline
        # ENTER alone => send
        if event.keysym == "Return":
            # Check if SHIFT is pressed
            # On Windows, SHIFT => event.state & 0x0001 doesn't always work. 
            # We'll use event.state & 4 on Windows. But let's do a simpler approach:
            # For cross-platform SHIFT detection in Tk, we can do:
            if (event.state & 0x0001) or (event.state & 0x0004):
                # SHIFT pressed => insert newline
                user_input_box.insert(tk.INSERT, "\n")
            else:
                # ENTER => send
                send_message(gui_dict)
            return "break"
        return None

    user_input_box.bind("<Return>", on_input_key)

    # Saving Directory + Auto-Save
    saveopt_frame = ttk.LabelFrame(container, text="Saving Directory / Auto-Save")
    saveopt_frame.pack(fill=tk.X, pady=5)

    saving_dir_var = tk.StringVar(value="C:/chat_history")
    ttk.Label(saveopt_frame, text="Saving Directory:").pack(side=tk.LEFT, padx=5)
    saveentry = ttk.Entry(saveopt_frame, textvariable=saving_dir_var, width=40)
    saveentry.pack(side=tk.LEFT, padx=5)

    auto_save_var = tk.IntVar(value=0)
    ttk.Checkbutton(saveopt_frame, text="Auto-Save on Send", variable=auto_save_var)\
        .pack(side=tk.LEFT, padx=10)

    # Action Buttons
    action_frame = ttk.Frame(container)
    action_frame.pack(fill=tk.X, pady=5)

    send_btn = ttk.Button(action_frame, text="Send")
    send_btn.pack(side=tk.LEFT, padx=5)

    stop_btn = ttk.Button(action_frame, text="Stop", command=stop_chat_func)
    stop_btn.pack(side=tk.LEFT, padx=5)

    clear_btn = ttk.Button(action_frame, text="Clear Chat", command=lambda: clear_chat_func(chat_box))
    clear_btn.pack(side=tk.LEFT, padx=5)

    load_btn = ttk.Button(action_frame, text="Load Chat")
    load_btn.pack(side=tk.LEFT, padx=5)

    save_btn = ttk.Button(action_frame, text="Save Chat")
    save_btn.pack(side=tk.LEFT, padx=5)

    copy_btn = ttk.Button(action_frame, text="Copy Last Assistant", command=lambda: copy_last_assistant(gui_dict))
    copy_btn.pack(side=tk.LEFT, padx=5)

    refresh_btn = ttk.Button(action_frame, text="Refresh Model", command=lambda: refresh_model_func(gui_dict))
    refresh_btn.pack(side=tk.LEFT, padx=5)

    # Gather references
    gui_dict = {
        "root": root,
        "api_provider_var":   api_provider_var,

        "ollama_address_var":  ollama_address_var,
        "groq_api_key_var":    groq_api_key_var,
        "openai_api_key_var":  openai_api_key_var,
        "together_api_key_var":together_api_key_var,
        "google_api_key_var":  google_api_key_var,
        "deepseek_api_key_var":deepseek_api_key_var,

        "ollama_model_var":    ollama_model_var,
        "groq_model_var":      groq_model_var,
        "openai_model_var":    openai_model_var,
        "together_model_var":  together_model_var,
        "google_model_var":    google_model_var,
        "deepseek_model_var":  deepseek_model_var,

        "chat_box":           chat_box,
        "user_input_box":     user_input_box,

        "saving_dir_var":     saving_dir_var,
        "auto_save_var":      auto_save_var
    }

    # Button callbacks
    send_btn.configure(command=lambda: send_message(gui_dict))
    load_btn.configure(command=lambda: load_chat_func(gui_dict, chat_box))
    save_btn.configure(command=lambda: save_chat_func(gui_dict, chat_box))
    load_keys_btn.configure(command=lambda: load_api_keys(gui_dict))

    root.mainloop()

if __name__ == "__main__":
    main()
