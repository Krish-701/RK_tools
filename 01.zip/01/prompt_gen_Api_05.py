import os
import re
import csv
import sys
import json
import subprocess
import requests
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

##############################################################################
# GLOBALS
##############################################################################

stop_generation = False
ALL_PROMPTS_MEMORY = {}

# For collapsible toggles (True = hidden, False = visible)
hidden_reference = False
hidden_title     = False
hidden_style     = False
hidden_detail    = False

##############################################################################
# PARSING & CLEANUP
##############################################################################

def parse_ollama_output(response: str):
    title_match = re.search(r'(?im)^\s*Title:\s*["“]?(.+?)["”]?\s*$', response)
    desc_match  = re.search(r'(?im)^\s*Description:\s*(.+)$', response)
    style_match = re.search(r'(?im)^\s*Style:\s*(.+)$', response)

    if not (title_match or desc_match or style_match):
        return None

    title = title_match.group(1).strip() if title_match else ""
    desc  = desc_match.group(1).strip()  if desc_match else ""
    style = style_match.group(1).strip() if style_match else ""

    if not (title or desc or style):
        return None

    return {"title": title, "description": desc, "style": style}

def clean_parsed_output(parsed_dict: dict):
    if not parsed_dict:
        return parsed_dict
    for k in ["title", "description", "style"]:
        parsed_dict[k] = re.sub(r'[\"\'\*]', '', parsed_dict.get(k, ""))
    return parsed_dict

##############################################################################
# API CALLS
##############################################################################

def call_ollama_api(address: str, model: str, full_prompt: str) -> str:
    if not address.startswith("http"):
        address = "http://" + address
    url = address.rstrip("/") + "/api/generate"
    payload = {"model": model, "prompt": full_prompt, "stream": True}
    final_text = ""
    try:
        with requests.post(url, json=payload, stream=True, timeout=120) as r:
            r.raise_for_status()
            for line in r.iter_lines(decode_unicode=True):
                if not line.strip():
                    continue
                try:
                    chunk = json.loads(line)
                    final_text += chunk.get("response", "")
                    if chunk.get("done"):
                        break
                except json.JSONDecodeError:
                    continue
        return final_text
    except Exception as e:
        return f"[ERROR streaming from Ollama] {str(e)}"

def call_groq_api(api_key: str, model: str, system_content: str, user_content: str) -> str:
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    data = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_content},
            {"role": "user",   "content": user_content}
        ]
    }
    try:
        resp = requests.post(url, headers=headers, json=data, timeout=120)
        resp.raise_for_status()
        j = resp.json()
        if "choices" in j and j["choices"]:
            return j["choices"][0]["message"]["content"]
        return "[ERROR] Groq response missing 'choices'"
    except Exception as e:
        return f"[ERROR from Groq] {str(e)}"

def call_openai_api(api_key: str, model: str, system_content: str, user_content: str) -> str:
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    data = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_content},
            {"role": "user",   "content": user_content}
        ]
    }
    try:
        resp = requests.post(url, headers=headers, json=data, timeout=120)
        resp.raise_for_status()
        j = resp.json()
        if "choices" in j and j["choices"]:
            return j["choices"][0]["message"]["content"]
        return "[ERROR] OpenAI response missing 'choices'"
    except Exception as e:
        return f"[ERROR from OpenAI] {str(e)}"

def call_together_api(api_key: str, model: str, system_content: str, user_content: str) -> str:
    url = "https://api.together.xyz/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    data = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_content},
            {"role": "user",   "content": user_content}
        ],
        "max_tokens": None,
        "temperature": 0.7,
        "top_p": 0.7,
        "top_k": 50,
        "repetition_penalty": 1,
        "stop": ["<|eot_id|>", "<|eom_id|>"],
        "stream": False
    }
    try:
        resp = requests.post(url, headers=headers, json=data, timeout=120)
        resp.raise_for_status()
        j = resp.json()
        if "choices" in j and j["choices"]:
            return j["choices"][0]["message"]["content"]
        return "[ERROR] Together response missing 'choices'"
    except Exception as e:
        return f"[ERROR from Together] {str(e)}"

def call_google_genai_api(api_key: str, model: str, system_content: str, user_content: str) -> str:
    try:
        import google.generativeai as genai
    except ImportError:
        return "[ERROR from Google] 'google-generativeai' not installed. Please pip install google-generativeai."

    google_map = {
        "gemini-2.0-flash-exp":       "gemini-2.0-flash-exp",
        "gemini-1.5-flash-latest":    "gemini-1.5-flash-latest",
        "gemini-1.5-flash-8b-latest": "gemini-1.5-flash-8b-latest",
        "gemini-1.5-pro-latest":      "gemini-1.5-pro-latest"
    }
    if model in google_map:
        model = google_map[model]

    print(f"[DEBUG] Google model chosen: {model}")

    try:
        genai.configure(api_key=api_key)
        prompt = f"{system_content}\n\n{user_content}"
        gm = genai.GenerativeModel(model)
        result = gm.generate_content(prompt)
        return result.text or "[EMPTY from Google]"
    except Exception as e:
        return f"[ERROR from Google] {str(e)}"

def call_deepseek_api(api_key: str, model: str, system_content: str, user_content: str) -> str:
    try:
        from openai import OpenAI
    except ImportError:
        return "[ERROR from DeepSeek] 'openai' package not installed. Please pip install openai."

    try:
        client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com")
        messages = [
            {"role": "system", "content": system_content},
            {"role": "user",   "content": user_content}
        ]
        resp = client.chat.completions.create(
            model=model,
            messages=messages,
            stream=False
        )
        if hasattr(resp, "choices") and resp.choices:
            return resp.choices[0].message.content
        return "[ERROR from DeepSeek] Response missing 'choices'"
    except Exception as e:
        return f"[ERROR from DeepSeek] {str(e)}"

##############################################################################
# DISPATCHER
##############################################################################

def call_llm_api(provider: str, gui: dict, system_content: str, user_content: str) -> str:
    provider = provider.lower()

    if provider == "ollama":
        model   = gui["ollama_model_var"].get()
        address = gui["ollama_address_var"].get().strip()
        full_prompt = f"{system_content}\n\n{user_content}\n"
        return call_ollama_api(address, model, full_prompt)

    elif provider == "groq":
        model   = gui["groq_model_var"].get()
        api_key = gui["groq_api_key_var"].get().strip()
        return call_groq_api(api_key, model, system_content, user_content)

    elif provider == "openai":
        model   = gui["openai_model_var"].get()
        api_key = gui["openai_api_key_var"].get().strip()
        return call_openai_api(api_key, model, system_content, user_content)

    elif provider == "together":
        model   = gui["together_model_var"].get()
        api_key = gui["together_api_key_var"].get().strip()
        return call_together_api(api_key, model, system_content, user_content)

    elif provider == "google":
        model   = gui["google_model_var"].get()
        api_key = gui["google_api_key_var"].get().strip()
        return call_google_genai_api(api_key, model, system_content, user_content)

    elif provider == "deepseek":
        model   = gui["deepseek_model_var"].get()
        api_key = gui["deepseek_api_key_var"].get().strip()
        return call_deepseek_api(api_key, model, system_content, user_content)

    else:
        return f"[ERROR] Unknown provider: {provider}"

##############################################################################
# SYSTEM / USER PROMPTS
##############################################################################

def build_base_system_prompt():
    return (
        "SYSTEM: You are an AI specializing in ultra-photorealistic image prompts.\n"
        "Generate a single-paragraph description, with:\n"
        "- Evocative language, cinematic lighting, micro & macro details.\n"
        "- Title:, Description:, Style: (in that format)\n"
        "----------------------------------------"
    )

def build_user_prompt(t: str, s: str, d: str, ref: str):
    lines = ["USER:"]
    lines.append(f"Use this Title exactly: '{t}'" if t else "Generate a random Title.")
    lines.append(f"Use this Style exactly: '{s}'" if s else "Generate a random Style.")
    lines.append(f"Follow this detail guideline: '{d}'" if d else "Use random detail guideline.")
    if ref.strip():
        lines.append(f"Incorporate reference: '{ref}'")
    lines.append("Now generate Title:, Description:, Style: lines.")
    return "\n".join(lines)

##############################################################################
# MEMORY (AVOID DUPLICATES)
##############################################################################

def show_memory_func(gui):
    box = gui["model_log_box"]
    if not ALL_PROMPTS_MEMORY:
        box.insert(tk.END, "[INFO] No memory stored.\n")
    else:
        box.insert(tk.END, "[INFO] Memory contents:\n")
        for model_name, prompts in ALL_PROMPTS_MEMORY.items():
            box.insert(tk.END, f"  {model_name}:\n")
            for idx, p in enumerate(prompts, start=1):
                box.insert(tk.END, f"   {idx}) {p}\n")

def reset_memory_func(gui):
    global ALL_PROMPTS_MEMORY
    ALL_PROMPTS_MEMORY.clear()
    gui["model_log_box"].insert(tk.END, "[INFO] Memory reset.\n")

##############################################################################
# CSV SAVE + OPEN CSV
##############################################################################

def save_prompts_to_csv(prompts_list, csv_path, save_mode, model_name, log_box):
    if not prompts_list:
        return
    dirp = os.path.dirname(csv_path)
    if dirp and not os.path.exists(dirp):
        os.makedirs(dirp, exist_ok=True)
    mode = "a" if save_mode == "append" else "w"
    write_header = not (mode == "a" and os.path.exists(csv_path))

    try:
        with open(csv_path, mode=mode, newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["Title","Description","Style"])
            if write_header:
                writer.writeheader()
            for p in prompts_list:
                writer.writerow({
                    "Title": p["title"],
                    "Description": p["description"],
                    "Style": p["style"]
                })
        log_box.insert(tk.END, f"[{model_name}] Saved {len(prompts_list)} prompts -> {csv_path}\n")
    except Exception as e:
        log_box.insert(tk.END, f"[ERROR saving CSV] {e}\n")

    prompts_list.clear()

def open_csv_file(csv_path):
    if not os.path.exists(csv_path):
        messagebox.showerror("File not found", f"CSV file not found: {csv_path}")
        return
    if sys.platform.startswith("win"):
        os.startfile(csv_path)
    elif sys.platform == "darwin":
        subprocess.call(["open", csv_path])
    else:
        subprocess.call(["xdg-open", csv_path])

def open_csv_in_explorer(csv_path):
    if not os.path.exists(csv_path):
        messagebox.showerror("File not found", f"CSV file not found: {csv_path}")
        return

    # If it's actually a file, highlight it on Windows
    if os.path.isfile(csv_path) and sys.platform.startswith("win"):
        subprocess.call(["explorer", "/select,", os.path.normpath(csv_path)])
        return

    # On Mac, try to reveal
    if sys.platform == "darwin":
        subprocess.call(["open", "-R", csv_path])
        return

    # Otherwise, open folder
    folder = os.path.dirname(csv_path)
    if not folder:
        messagebox.showerror("No folder", "No folder found from CSV path.")
        return
    subprocess.call(["xdg-open", folder])

##############################################################################
# MAIN GENERATION
##############################################################################

def generate_prompts_for_model(gui):
    global stop_generation, ALL_PROMPTS_MEMORY
    stop_generation = False

    provider = gui["api_provider_var"].get().lower()
    log_box  = gui["model_log_box"]
    progress = gui["progress_bar"]

    # CSV / Memory
    output_csv = gui["output_file_var"].get().strip()
    save_mode  = gui["save_mode_var"].get()
    use_memory = (gui["use_memory_var"].get() == 1)
    auto_every = int(gui["auto_save_every_var"].get() or 0)
    auto_scroll= (gui["auto_scroll_var"].get() == 1)

    # Title/Style/Detail
    title_inp  = gui["title_box"].get("1.0", tk.END).strip()
    style_inp  = gui["style_box"].get("1.0", tk.END).strip()
    detail_inp = gui["detail_box"].get("1.0", tk.END).strip()
    reference  = gui["reference_box"].get("1.0", tk.END).strip()

    # Prompt count
    num_prompts = int(gui["prompt_count_var"].get())

    system_prompt = build_base_system_prompt()

    new_prompts = []
    success_count = 0
    attempts = 0
    max_attempts = num_prompts * 10

    while success_count < num_prompts and attempts < max_attempts:
        if stop_generation:
            log_box.insert(tk.END, "\n[INFO] Stopped by user.\n")
            if auto_scroll:
                log_box.see(tk.END)
            break

        attempts += 1

        # Based on provider, pick model from combos
        if provider == "ollama":
            model_name = gui["ollama_model_var"].get()
        elif provider == "groq":
            model_name = gui["groq_model_var"].get()
        elif provider == "openai":
            model_name = gui["openai_model_var"].get()
        elif provider == "together":
            model_name = gui["together_model_var"].get()
        elif provider == "google":
            model_name = gui["google_model_var"].get()
        elif provider == "deepseek":
            model_name = gui["deepseek_model_var"].get()
        else:
            model_name = "unknown_model"

        if model_name not in ALL_PROMPTS_MEMORY:
            ALL_PROMPTS_MEMORY[model_name] = []

        # Build memory text
        memory_txt = ""
        if use_memory and ALL_PROMPTS_MEMORY[model_name]:
            lines = []
            for p in ALL_PROMPTS_MEMORY[model_name]:
                lines.append(f"{p['title']}|{p['description']}|{p['style']}")
            memory_txt = "Previously created:\n" + "\n".join(lines) + "\nDON'T REPEAT."

        final_system = system_prompt + "\n" + memory_txt
        user_prompt  = build_user_prompt(title_inp, style_inp, detail_inp, reference)

        # Actual LLM call
        resp = call_llm_api(provider, gui, final_system, user_prompt)

        parsed = parse_ollama_output(resp)
        if not parsed:
            parsed = {"title":"UNPARSED","description":resp,"style":""}
        parsed = clean_parsed_output(parsed)
        if parsed["title"].upper() == "UNPARSED":
            parsed["title"] = ""

        # Check duplicates
        mem_list = ALL_PROMPTS_MEMORY[model_name] if use_memory else new_prompts
        is_dup = any(
            p["title"] == parsed["title"] and
            p["description"] == parsed["description"] and
            p["style"] == parsed["style"]
            for p in mem_list
        )
        if is_dup:
            log_box.insert(tk.END, f"[{model_name}] Duplicate found, skip.\n")
            if auto_scroll:
                log_box.see(tk.END)
            continue

        # Accept it
        success_count += 1
        new_prompts.append(parsed)
        if use_memory:
            ALL_PROMPTS_MEMORY[model_name].append(parsed)

        log_box.insert(
            tk.END,
            f"[{model_name}] #{success_count}/{num_prompts}\n"
            f"Title: {parsed['title']}\n"
            f"Description: {parsed['description']}\n"
            f"Style: {parsed['style']}\n\n"
        )
        if auto_scroll:
            log_box.see(tk.END)

        progress["value"] = int((success_count/num_prompts)*100)

        # Auto-save partial
        if auto_every>0 and (success_count % auto_every==0):
            save_prompts_to_csv(new_prompts, output_csv, save_mode, model_name, log_box)

    # Final save
    if new_prompts:
        save_prompts_to_csv(new_prompts, output_csv, save_mode, model_name, log_box)

    log_box.insert(tk.END, "[INFO] Generation finished.\n")
    if auto_scroll:
        log_box.see(tk.END)

##############################################################################
# COLLAPSIBLE: Show/Hide
##############################################################################

def toggle_reference():
    global hidden_reference
    hidden_reference = not hidden_reference
    if hidden_reference:
        reference_frame.grid_remove()
        ref_button.config(text="Show")
    else:
        reference_frame.grid()
        ref_button.config(text="Hide")

def toggle_title():
    global hidden_title
    hidden_title = not hidden_title
    if hidden_title:
        title_frame.grid_remove()
        title_button.config(text="Show")
    else:
        title_frame.grid()
        title_button.config(text="Hide")

def toggle_style():
    global hidden_style
    hidden_style = not hidden_style
    if hidden_style:
        style_frame.grid_remove()
        style_button.config(text="Show")
    else:
        style_frame.grid()
        style_button.config(text="Hide")

def toggle_detail():
    global hidden_detail
    hidden_detail = not hidden_detail
    if hidden_detail:
        detail_frame.grid_remove()
        detail_button.config(text="Show")
    else:
        detail_frame.grid()
        detail_button.config(text="Hide")

##############################################################################
# THREAD STOP / START
##############################################################################

def generate_threaded(gui):
    thread = threading.Thread(target=generate_prompts_for_model, args=(gui,))
    thread.start()

def stop_generation_func():
    global stop_generation
    stop_generation = True

##############################################################################
# LOAD KEYS FROM FILE
##############################################################################

def load_api_keys_from_file(
    groq_var, openai_var, together_var, google_var, deepseek_var, ollama_var
):
    """
    User selects a .txt file with lines like:
        groq=MY_GROQ_KEY
        openai=MY_OPENAI_KEY
        google=MY_GOOGLE_KEY
        deepseek=MY_DEEPSEEK_KEY
        together=MY_TOGETHER_KEY
        ollama=http://localhost:11434
    We'll parse each line, if recognized, update the corresponding variable.
    """
    path = filedialog.askopenfilename(
        title="Open API Key File",
        filetypes=[("Text Files","*.txt"), ("All Files","*.*")]
    )
    if not path:
        return  # user canceled

    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or "=" not in line:
                    continue
                key, val = line.split("=", 1)
                key = key.lower().strip()
                val = val.strip()
                if key == "groq":
                    groq_var.set(val)
                elif key == "openai":
                    openai_var.set(val)
                elif key == "together":
                    together_var.set(val)
                elif key == "google":
                    google_var.set(val)
                elif key == "deepseek":
                    deepseek_var.set(val)
                elif key == "ollama":
                    ollama_var.set(val)

        messagebox.showinfo("Load Complete", "API keys loaded from file.")
    except Exception as e:
        messagebox.showerror("Error", f"Error reading file:\n{e}")

##############################################################################
# MAIN TKINTER
##############################################################################

def main():
    root = tk.Tk()
    root.title("Multi-Provider Prompt Generator (Collapsible in same place + Load Keys from file)")
    root.geometry("1400x1100")  # can adjust as needed

    # MASTER SCROLLABLE CANVAS
    main_canvas = tk.Canvas(root)
    main_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    scrollbar = ttk.Scrollbar(root, orient=tk.VERTICAL, command=main_canvas.yview)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    main_canvas.configure(yscrollcommand=scrollbar.set)

    container = ttk.Frame(main_canvas)
    main_canvas.create_window((0,0), window=container, anchor="nw")

    def on_configure(event):
        main_canvas.configure(scrollregion=main_canvas.bbox("all"))
    container.bind("<Configure>", on_configure)

    def _on_mousewheel(event):
        main_canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    main_canvas.bind("<MouseWheel>", _on_mousewheel)         # Windows/Mac
    main_canvas.bind("<Button-4>", lambda e: main_canvas.yview_scroll(-1, "units"))  # Linux up
    main_canvas.bind("<Button-5>", lambda e: main_canvas.yview_scroll(1, "units"))   # Linux down

    # ------------------------------------------------------------------------
    # Provider selection (radio buttons)
    # ------------------------------------------------------------------------
    provider_frame = ttk.LabelFrame(container, text="Select Provider (One)")
    provider_frame.pack(fill=tk.X, pady=5)

    api_provider_var = tk.StringVar(value="ollama")
    for p in ["ollama","groq","openai","together","google","deepseek"]:
        ttk.Radiobutton(provider_frame, text=p.capitalize(), variable=api_provider_var, value=p)\
            .pack(side=tk.LEFT, padx=5)

    # ------------------------------------------------------------------------
    # API Keys & Ollama Address (HORIZONTAL LAYOUT)
    # ------------------------------------------------------------------------
    api_keys_frame = ttk.LabelFrame(container, text="API Keys & Ollama Address (Horizontal)")
    api_keys_frame.pack(fill=tk.X, pady=5)

    groq_api_key_var      = tk.StringVar(value="")
    openai_api_key_var    = tk.StringVar(value="")
    together_api_key_var  = tk.StringVar(value="")
    google_api_key_var    = tk.StringVar(value="")
    deepseek_api_key_var  = tk.StringVar(value="")
    ollama_address_var    = tk.StringVar(value="http://localhost:11434")

    colnum = 0
    ttk.Label(api_keys_frame, text="Groq Key:").grid(row=0, column=colnum, padx=5, pady=5, sticky=tk.E)
    colnum += 1
    ttk.Entry(api_keys_frame, textvariable=groq_api_key_var, width=20)\
        .grid(row=0, column=colnum, padx=5, pady=5, sticky=tk.W)
    colnum += 1

    ttk.Label(api_keys_frame, text="OpenAI Key:").grid(row=0, column=colnum, padx=5, pady=5, sticky=tk.E)
    colnum += 1
    ttk.Entry(api_keys_frame, textvariable=openai_api_key_var, width=20)\
        .grid(row=0, column=colnum, padx=5, pady=5, sticky=tk.W)
    colnum += 1

    ttk.Label(api_keys_frame, text="Together Key:").grid(row=0, column=colnum, padx=5, pady=5, sticky=tk.E)
    colnum += 1
    ttk.Entry(api_keys_frame, textvariable=together_api_key_var, width=20)\
        .grid(row=0, column=colnum, padx=5, pady=5, sticky=tk.W)
    colnum += 1

    ttk.Label(api_keys_frame, text="Google Key:").grid(row=0, column=colnum, padx=5, pady=5, sticky=tk.E)
    colnum += 1
    ttk.Entry(api_keys_frame, textvariable=google_api_key_var, width=20)\
        .grid(row=0, column=colnum, padx=5, pady=5, sticky=tk.W)
    colnum += 1

    ttk.Label(api_keys_frame, text="DeepSeek Key:").grid(row=0, column=colnum, padx=5, pady=5, sticky=tk.E)
    colnum += 1
    ttk.Entry(api_keys_frame, textvariable=deepseek_api_key_var, width=20)\
        .grid(row=0, column=colnum, padx=5, pady=5, sticky=tk.W)
    colnum += 1

    ttk.Label(api_keys_frame, text="Ollama Address:").grid(row=0, column=colnum, padx=5, pady=5, sticky=tk.E)
    colnum += 1
    ttk.Entry(api_keys_frame, textvariable=ollama_address_var, width=20)\
        .grid(row=0, column=colnum, padx=5, pady=5, sticky=tk.W)

    # NEW BUTTON to load keys from a file:
    load_keys_btn = ttk.Button(api_keys_frame, text="Load Keys from File...",
        command=lambda: load_api_keys_from_file(
            groq_api_key_var, 
            openai_api_key_var, 
            together_api_key_var, 
            google_api_key_var, 
            deepseek_api_key_var, 
            ollama_address_var
        )
    )
    colnum += 1
    load_keys_btn.grid(row=0, column=colnum, padx=5, pady=5)

    # ------------------------------------------------------------------------
    # Models for each Provider
    # ------------------------------------------------------------------------
    model_frame = ttk.LabelFrame(container, text="Models for each Provider (Pick One)")
    model_frame.pack(fill=tk.X, pady=5)

    ollama_model_var = tk.StringVar()
    ollama_models = [
        "mistral-small:22b-instruct-2409-q8_0",
        "llama3.2:1b"
    ]
    ttk.Label(model_frame, text="Ollama:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
    c1 = ttk.Combobox(model_frame, textvariable=ollama_model_var, values=ollama_models, width=25)
    c1.grid(row=0, column=1, padx=5, pady=2)
    c1.current(0)

    groq_model_var = tk.StringVar()
    groq_models = [
        "llama-3.3-70b-versatile",
        "mixtral-8x7b-32768"
    ]
    ttk.Label(model_frame, text="Groq:").grid(row=0, column=2, sticky=tk.W, padx=5, pady=2)
    c2 = ttk.Combobox(model_frame, textvariable=groq_model_var, values=groq_models, width=25)
    c2.grid(row=0, column=3, padx=5, pady=2)
    c2.current(0)

    openai_model_var = tk.StringVar()
    openai_models = [
        "gpt-4o"
    ]
    ttk.Label(model_frame, text="OpenAI:").grid(row=0, column=4, sticky=tk.W, padx=5, pady=2)
    c3 = ttk.Combobox(model_frame, textvariable=openai_model_var, values=openai_models, width=25)
    c3.grid(row=0, column=5, padx=5, pady=2)
    c3.current(0)

    together_model_var = tk.StringVar()
    together_models = [
        "meta-llama/Llama-Vision-Free",
        "black-forest-labs/FLUX.1-schnell-Free"
    ]
    ttk.Label(model_frame, text="Together:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
    c4 = ttk.Combobox(model_frame, textvariable=together_model_var, values=together_models, width=25)
    c4.grid(row=1, column=1, padx=5, pady=2)
    c4.current(0)

    google_model_var = tk.StringVar()
    google_models = [
        "gemini-2.0-flash-exp",
        "gemini-1.5-flash-latest",
        "gemini-1.5-flash-8b-latest",
        "gemini-1.5-pro-latest"
    ]
    ttk.Label(model_frame, text="Google:").grid(row=1, column=2, sticky=tk.W, padx=5, pady=2)
    c5 = ttk.Combobox(model_frame, textvariable=google_model_var, values=google_models, width=25)
    c5.grid(row=1, column=3, padx=5, pady=2)
    c5.current(1)  # default "gemini-1.5-flash-latest"

    deepseek_model_var = tk.StringVar()
    deepseek_models = [
        "deepseek-chat",
        "deepseek-other-model"
    ]
    ttk.Label(model_frame, text="DeepSeek:").grid(row=1, column=4, sticky=tk.W, padx=5, pady=2)
    c6 = ttk.Combobox(model_frame, textvariable=deepseek_model_var, values=deepseek_models, width=25)
    c6.grid(row=1, column=5, padx=5, pady=2)
    c6.current(0)

    # ------------------------------------------------------------------------
    # Prompt Count & CSV
    # ------------------------------------------------------------------------
    count_frame = ttk.LabelFrame(container, text="Prompt Count & CSV")
    count_frame.pack(fill=tk.X, pady=5)

    ttk.Label(count_frame, text="Number of Prompts:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
    prompt_count_var = tk.StringVar(value="5")
    ttk.Entry(count_frame, textvariable=prompt_count_var, width=6).grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)

    ttk.Label(count_frame, text="Output CSV:").grid(row=0, column=2, padx=5, pady=5, sticky=tk.W)
    output_file_var = tk.StringVar(value="C:/prompts/output.csv")
    ttk.Entry(count_frame, textvariable=output_file_var, width=40).grid(row=0, column=3, padx=5, pady=5, sticky=tk.W)

    ttk.Button(count_frame, text="Browse...", command=lambda: browse_csv_file(output_file_var))\
        .grid(row=0, column=4, padx=5, pady=5)

    # ------------------------------------------------------------------------
    # Collapsible Frames (Grid approach to keep them in place)
    # ------------------------------------------------------------------------
    collapsible_container = ttk.Frame(container)
    collapsible_container.pack(fill=tk.X, padx=5, pady=5)

    # Reference
    global ref_button, reference_frame
    ref_button_frame = ttk.Frame(collapsible_container)
    ref_button_frame.grid(row=0, column=0, sticky="ew", pady=5)
    ref_button = ttk.Button(ref_button_frame, text="Hide", command=toggle_reference)
    ref_button.pack(side=tk.LEFT, padx=5)
    ttk.Label(ref_button_frame, text="Reference Text").pack(side=tk.LEFT, padx=5)

    reference_frame = ttk.Frame(collapsible_container)
    reference_frame.grid(row=1, column=0, sticky="ew")
    reference_box = tk.Text(reference_frame, height=5, wrap=tk.WORD)
    reference_box.pack(fill=tk.BOTH, expand=True)
    reference_box.insert(tk.END, "Add reference text or instructions here...")

    # Title
    global title_button, title_frame
    title_button_frame = ttk.Frame(collapsible_container)
    title_button_frame.grid(row=2, column=0, sticky="ew", pady=5)
    title_button = ttk.Button(title_button_frame, text="Hide", command=toggle_title)
    title_button.pack(side=tk.LEFT, padx=5)
    ttk.Label(title_button_frame, text="Title").pack(side=tk.LEFT, padx=5)

    title_frame = ttk.Frame(collapsible_container)
    title_frame.grid(row=3, column=0, sticky="ew")
    title_box = tk.Text(title_frame, height=3, wrap=tk.WORD)
    title_box.pack(fill=tk.BOTH, expand=True)

    # Style
    global style_button, style_frame
    style_button_frame = ttk.Frame(collapsible_container)
    style_button_frame.grid(row=4, column=0, sticky="ew", pady=5)
    style_button = ttk.Button(style_button_frame, text="Hide", command=toggle_style)
    style_button.pack(side=tk.LEFT, padx=5)
    ttk.Label(style_button_frame, text="Style").pack(side=tk.LEFT, padx=5)

    style_frame = ttk.Frame(collapsible_container)
    style_frame.grid(row=5, column=0, sticky="ew")
    style_box = tk.Text(style_frame, height=3, wrap=tk.WORD)
    style_box.pack(fill=tk.BOTH, expand=True)

    # Detail
    global detail_button, detail_frame
    detail_button_frame = ttk.Frame(collapsible_container)
    detail_button_frame.grid(row=6, column=0, sticky="ew", pady=5)
    detail_button = ttk.Button(detail_button_frame, text="Hide", command=toggle_detail)
    detail_button.pack(side=tk.LEFT, padx=5)
    ttk.Label(detail_button_frame, text="Detail").pack(side=tk.LEFT, padx=5)

    detail_frame = ttk.Frame(collapsible_container)
    detail_frame.grid(row=7, column=0, sticky="ew")
    detail_box = tk.Text(detail_frame, height=3, wrap=tk.WORD)
    detail_box.pack(fill=tk.BOTH, expand=True)

    # ------------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------------
    settings_frame = ttk.LabelFrame(container, text="Settings")
    settings_frame.pack(fill=tk.X, pady=5)

    use_memory_var = tk.IntVar(value=1)
    ttk.Checkbutton(settings_frame, text="Use Memory (avoid repeats)", variable=use_memory_var)\
        .grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)

    save_mode_var = tk.StringVar(value="append")
    ttk.Radiobutton(settings_frame, text="Overwrite", variable=save_mode_var, value="overwrite")\
        .grid(row=0, column=1, padx=5)
    ttk.Radiobutton(settings_frame, text="Append",   variable=save_mode_var, value="append")\
        .grid(row=0, column=2, padx=5)

    ttk.Label(settings_frame, text="Auto-Save Every:")\
        .grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
    auto_save_every_var = tk.StringVar(value="50")
    ttk.Entry(settings_frame, textvariable=auto_save_every_var, width=6)\
        .grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)

    auto_scroll_var = tk.IntVar(value=1)
    ttk.Checkbutton(settings_frame, text="Auto-scroll Log", variable=auto_scroll_var)\
        .grid(row=1, column=2, padx=5, pady=5, sticky=tk.W)

    # ------------------------------------------------------------------------
    # Action Buttons
    # ------------------------------------------------------------------------
    action_frame = ttk.Frame(container)
    action_frame.pack(fill=tk.X, pady=5)

    model_log_box = None
    progress_bar  = None

    start_btn = ttk.Button(action_frame, text="Start")
    start_btn.pack(side=tk.LEFT, padx=5)

    stop_btn = ttk.Button(action_frame, text="Stop", command=stop_generation_func)
    stop_btn.pack(side=tk.LEFT, padx=5)

    reset_btn = ttk.Button(action_frame, text="Reset Memory",
        command=lambda: reset_memory_func({"model_log_box": model_log_box})
    )
    reset_btn.pack(side=tk.LEFT, padx=5)

    showmem_btn = ttk.Button(action_frame, text="Show Memory",
        command=lambda: show_memory_func({"model_log_box": model_log_box})
    )
    showmem_btn.pack(side=tk.LEFT, padx=5)

    open_csv_btn = ttk.Button(action_frame, text="Open CSV",
        command=lambda: open_csv_file(output_file_var.get()))
    open_csv_btn.pack(side=tk.LEFT, padx=5)

    open_csv_exp_btn = ttk.Button(action_frame, text="Open CSV in Explorer",
        command=lambda: open_csv_in_explorer(output_file_var.get()))
    open_csv_exp_btn.pack(side=tk.LEFT, padx=5)

    clear_log_btn = ttk.Button(action_frame, text="Clear Log",
        command=lambda: model_log_box.delete("1.0", tk.END))
    clear_log_btn.pack(side=tk.LEFT, padx=5)

    # ------------------------------------------------------------------------
    # Log & Progress
    # ------------------------------------------------------------------------
    log_frame = ttk.LabelFrame(container, text="Log Output")
    log_frame.pack(fill=tk.BOTH, expand=True, pady=5)

    scrollbar_log = ttk.Scrollbar(log_frame, orient=tk.VERTICAL)
    model_log_box = tk.Text(log_frame, yscrollcommand=scrollbar_log.set, wrap=tk.WORD)
    model_log_box.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar_log.config(command=model_log_box.yview)
    scrollbar_log.pack(side=tk.RIGHT, fill=tk.Y)

    progress_frame = ttk.Frame(container)
    progress_frame.pack(fill=tk.X, pady=5)
    progress_bar = ttk.Progressbar(progress_frame, orient="horizontal", mode="determinate", length=550)
    progress_bar.pack(side=tk.LEFT, padx=5)

    # Wire up "Start"
    start_btn.configure(
        command=lambda: generate_threaded({
            "api_provider_var":        api_provider_var,

            "groq_api_key_var":        groq_api_key_var,
            "openai_api_key_var":      openai_api_key_var,
            "together_api_key_var":    together_api_key_var,
            "google_api_key_var":      google_api_key_var,
            "deepseek_api_key_var":    deepseek_api_key_var,
            "ollama_address_var":      ollama_address_var,

            "ollama_model_var":        ollama_model_var,
            "groq_model_var":          groq_model_var,
            "openai_model_var":        openai_model_var,
            "together_model_var":      together_model_var,
            "google_model_var":        google_model_var,
            "deepseek_model_var":      deepseek_model_var,

            "prompt_count_var":        prompt_count_var,
            "output_file_var":         output_file_var,
            "save_mode_var":           save_mode_var,
            "use_memory_var":          use_memory_var,
            "auto_save_every_var":     auto_save_every_var,
            "auto_scroll_var":         auto_scroll_var,

            "title_box":               title_box,
            "style_box":               style_box,
            "detail_box":              detail_box,
            "reference_box":           reference_box,

            "model_log_box":           model_log_box,
            "progress_bar":            progress_bar
        })
    )

    root.mainloop()

if __name__ == "__main__":
    main()
